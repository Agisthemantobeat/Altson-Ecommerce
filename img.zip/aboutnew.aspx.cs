﻿using System;
using System.Web.UI;

namespace ALTSON_NEW
{
    public partial class WebForm1 : Page
    {
       protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}